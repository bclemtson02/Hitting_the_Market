def test_imports():
    import importlib
    importlib.import_module("pipeline_core")
