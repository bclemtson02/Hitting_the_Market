
import warnings
warnings.filterwarnings("ignore")

from typing import Tuple, List
from pathlib import Path

import numpy as np
import pandas as pd

from sklearn.model_selection import train_test_split
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression, LinearRegression
from sklearn.metrics import (
    accuracy_score, f1_score, classification_report, roc_auc_score,
    r2_score, mean_absolute_error, mean_squared_error
)
import joblib


def infer_task_type(y: pd.Series) -> str:
    """Return 'classification' or 'regression' based on y dtype/uniqueness."""
    if pd.api.types.is_numeric_dtype(y):
        nunique = y.nunique(dropna=True)
        if nunique <= 10:
            return "classification"
        return "regression"
    return "classification"


def split_features(df: pd.DataFrame, target: str):
    if target not in df.columns:
        raise ValueError(f"Target column '{target}' not found. Available columns: {list(df.columns)[:20]}...")
    y = df[target]
    X = df.drop(columns=[target])

    cat_cols = X.select_dtypes(include=["object", "category", "bool"]).columns.tolist()
    num_cols = X.select_dtypes(include=["number"]).columns.tolist()

    return X, y, num_cols, cat_cols


def build_preprocessor(numeric_features: List[str], categorical_features: List[str]) -> ColumnTransformer:
    numeric_transformer = Pipeline(steps=[
        ("imputer", SimpleImputer(strategy="median")),
        ("scaler", StandardScaler())
    ])
    categorical_transformer = Pipeline(steps=[
        ("imputer", SimpleImputer(strategy="most_frequent")),
        ("onehot", OneHotEncoder(handle_unknown="ignore"))
    ])

    preprocessor = ColumnTransformer(
        transformers=[
            ("num", numeric_transformer, numeric_features),
            ("cat", categorical_transformer, categorical_features),
        ],
        remainder="drop"
    )
    return preprocessor


def build_baseline_model(task_type: str, y: pd.Series):
    if task_type == "classification":
        counts = y.value_counts(dropna=True)
        ratio = counts.max() / max(1, counts.min()) if len(counts) > 1 else 1.0
        if ratio >= 4.0:
            return LogisticRegression(max_iter=1000, class_weight="balanced", n_jobs=None)
        return LogisticRegression(max_iter=1000, n_jobs=None)
    else:
        return LinearRegression()


def evaluate(task_type: str, y_true, y_pred, y_proba=None):
    if task_type == "classification":
        acc = accuracy_score(y_true, y_pred)
        f1 = f1_score(y_true, y_pred, average="macro")
        print("\n=== Classification Metrics ===")
        print(f"Accuracy: {acc:0.4f}")
        print(f"F1 (macro): {f1:0.4f}")
        try:
            if y_proba is not None:
                if hasattr(y_true, "values"):
                    yt = y_true.values
                else:
                    yt = y_true
                if y_proba.ndim == 2 and y_proba.shape[1] == 2:
                    roc = roc_auc_score(yt, y_proba[:, 1])
                    print(f"ROC AUC: {roc:0.4f}")
                elif y_proba.ndim == 1:
                    roc = roc_auc_score(yt, y_proba)
                    print(f"ROC AUC: {roc:0.4f}")
        except Exception:
            pass
        print("\nClassification report:")
        print(classification_report(y_true, y_pred))
    else:
        r2 = r2_score(y_true, y_pred)
        mae = mean_absolute_error(y_true, y_pred)
        rmse = mean_squared_error(y_true, y_pred, squared=False)
        print("\n=== Regression Metrics ===")
        print(f"R^2:  {r2:0.4f}")
        print(f"MAE:  {mae:0.4f}")
        print(f"RMSE: {rmse:0.4f}")


def train_pipeline(
    data_path: Path,
    target_col: str,
    sheet_name: str = "Clean",
    test_size: float = 0.2,
    random_state: int = 42
):
    if not data_path.exists():
        raise FileNotFoundError(f"Data file not found at: {data_path}")

    print(f"Loading: {data_path} (sheet='{sheet_name}')")
    df = pd.read_excel(data_path, sheet_name=sheet_name)

    X, y, num_cols, cat_cols = split_features(df, target_col)
    print(f"Detected {len(num_cols)} numeric and {len(cat_cols)} categorical feature(s).")

    task_type = infer_task_type(y)
    print(f"Inferred task type: {task_type}")

    stratify = y if (task_type == "classification" and y.nunique() > 1) else None
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=test_size, random_state=random_state, stratify=stratify
    )

    preprocessor = build_preprocessor(num_cols, cat_cols)
    model = build_baseline_model(task_type, y_train)

    pipe = Pipeline(steps=[
        ("preprocess", preprocessor),
        ("model", model)
    ])

    pipe.fit(X_train, y_train)
    y_pred = pipe.predict(X_test)

    y_proba = None
    if task_type == "classification" and hasattr(pipe.named_steps["model"], "predict_proba"):
        try:
            y_proba = pipe.predict_proba(X_test)
        except Exception:
            y_proba = None

    evaluate(task_type, y_test, y_pred, y_proba)
    return pipe, task_type
