
"""
CLI entrypoint for training a hitters model with scikit-learn.
Usage example:
    python src/train_hitters.py \
        --data "/path/to/batters_joined_batting.xlsx" \
        --target "TARGET_COLUMN_NAME" \
        --model-out "artifacts/hitters_model.pkl"
"""

import argparse
from pathlib import Path
import joblib

from pipeline_core import train_pipeline


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--data", type=str, required=False, default="/mnt/data/batters_joined_batting.xlsx",
                   help="Path to Excel file with a 'Clean' sheet.")
    p.add_argument("--target", type=str, required=True, help="Target column in the sheet.")
    p.add_argument("--sheet", type=str, default="Clean", help="Sheet name (default: Clean).")
    p.add_argument("--test-size", type=float, default=0.2, help="Test size fraction (default: 0.2).")
    p.add_argument("--random-state", type=int, default=42, help="Random seed (default: 42).")
    p.add_argument("--model-out", type=str, default="artifacts/hitters_model.pkl",
                   help="Where to save the trained pipeline.")
    p.add_argument("--check", action="store_true",
                   help="Quick check: import modules, print args, and exit without training.")
    return p.parse_args()


def main():
    args = parse_args()
    if args.check:
        print("Check mode OK. Parsed args:", args)
        return

    pipe, task_type = train_pipeline(
        data_path=Path(args.data),
        target_col=args.target,
        sheet_name=args.sheet,
        test_size=args.test_size,
        random_state=args.random_state
    )

    out = Path(args.model_out)
    out.parent.mkdir(parents=True, exist_ok=True)
    joblib.dump(pipe, out)
    print(f"\nSaved trained pipeline to: {out.resolve()}")
    print(f"Task type: {task_type}")


if __name__ == "__main__":
    main()
