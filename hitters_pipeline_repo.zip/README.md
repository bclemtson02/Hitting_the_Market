# Hitters ML Pipeline (scikit-learn)

This repository scaffolds a clean, GitHub-ready pipeline for training a **hitters** model from your Excel `"Clean"` sheet.

## Quick start (local)

1. **Clone** this repo or copy these files into a new GitHub repository.
2. **Install** dependencies:
   ```bash
   make install
   # or: pip install -r requirements.txt
   ```
3. **Train** (edit the target column first):
   ```bash
   make train
   # or:
   python src/train_hitters.py \
       --data "/absolute/path/to/batters_joined_batting.xlsx" \
       --sheet Clean \
       --target "<TARGET_COLUMN_NAME>" \
       --model-out artifacts/hitters_model.pkl
   ```

The script prints evaluation metrics and saves a fitted pipeline at `artifacts/hitters_model.pkl`.

> **Note on data**: avoid committing large or private datasets. By default, the `data/` folder and `artifacts/` are gitignored.

## GitHub Actions (CI)

A minimal CI workflow is included at `.github/workflows/ci.yml`. It:
- Sets up Python
- Installs dependencies
- Runs a **check mode** to ensure the training entrypoint imports and the CLI works.

You can extend this to run real training with a small sample dataset, or trigger a manual training (`workflow_dispatch`) with secrets pointing to a data location (e.g., S3, GCS, etc.).

## Repo layout

```
.
├── .github/workflows/ci.yml
├── .gitignore
├── Makefile
├── README.md
├── requirements.txt
├── src
│   ├── pipeline_core.py
│   └── train_hitters.py
├── tests
│   └── test_imports.py
└── artifacts/        # model outputs (gitignored)
```

## Next steps

- Add hyperparameter tuning (GridSearchCV/RandomizedSearchCV).
- Log runs and metrics (e.g., MLflow).
- Use DVC or Git LFS for dataset versioning.
- Create a parallel `train_pitchers.py` reusing the same `pipeline_core.py`.
