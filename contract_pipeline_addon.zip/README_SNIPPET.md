## Contracts add-on (hitters)

**Goal:** Predict future contract size and length from pre-contract stats.

### 1) Build the training table
Upload your contracts Excel to `data/contracts_hitters.xlsx` with a `Clean` sheet. Required columns (case-insensitive by default):
- `player`
- `contract_start_year` (first season of the new deal)
- `contract_years`
- `contract_total_value`

Then run:
```bash
make build-contract-data
```
This aligns each contract to the **previous season's** stats (offset=1) and builds `data/hitters_contract_train.csv` with targets:
- `target_total_value`
- `target_years`
- `target_aav` (derived)

You can change the rolling window or alignment via flags in the Makefile target.

### 2) Train the model
Linear baseline:
```bash
make train-contracts-linear
```
Random Forest (nonlinear baseline):
```bash
make train-contracts-rf
```

### Notes on leakage & economics
- We **only** use stats from seasons *before* the contract starts to prevent leakage.
- Consider normalizing dollar amounts across years (inflation/CBA effects). If you have an index column, you can merge it before training or add a feature like `% of luxury tax threshold`.
