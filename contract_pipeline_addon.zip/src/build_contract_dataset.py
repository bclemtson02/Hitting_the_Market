
"""
Build a hitters contract training dataset by aligning *pre-contract* stats to contract outcomes.

Default alignment:
- Uses stats from the season immediately BEFORE the contract start year (offset=1).
- Optionally computes rolling means over the N most recent seasons up to that anchor season.

Outputs a single table with:
- Features: stats (optionally rolling-mean features)
- Targets: target_total_value, target_years, and target_aav (total_value / years)
- ID columns passed through for traceability

Example:
    python src/build_contract_dataset.py \
        --stats data/batters_joined_batting.xlsx \
        --contracts data/contracts_hitters.xlsx \
        --player-stats player --season-stats season \
        --player-contracts player --contract-year-col contract_start_year \
        --years-col contract_years --total-value-col contract_total_value \
        --rolling 3 --align-offset 1 \
        --out data/hitters_contract_train.csv
"""

import argparse
from pathlib import Path
import pandas as pd
import numpy as np

def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--stats", required=True, help="Path to hitters stats Excel (with 'Clean' sheet).")
    p.add_argument("--contracts", required=True, help="Path to contracts Excel (with 'Clean' sheet).")
    p.add_argument("--sheet-stats", default="Clean")
    p.add_argument("--sheet-contracts", default="Clean")

    p.add_argument("--player-stats", default="player", help="Player column in stats file.")
    p.add_argument("--season-stats", default="season", help="Season (year) column in stats file.")

    p.add_argument("--player-contracts", default="player", help="Player column in contracts file.")
    p.add_argument("--contract-year-col", default="contract_start_year", help="Column for first year of new contract.")
    p.add_argument("--years-col", default="contract_years", help="Column with contract length (years).")
    p.add_argument("--total-value-col", default="contract_total_value", help="Column with total contract value.")

    p.add_argument("--align-offset", type=int, default=1,
                   help="Use stats from (contract_year - offset). Default 1.")
    p.add_argument("--rolling", type=int, default=0,
                   help="If >0, compute rolling means over this window of prior seasons ending at anchor season.")

    p.add_argument("--id-pass-through", default="", 
                   help="Comma-separated list of ID columns from contracts to keep (e.g., 'player_id,team,sign_date').")

    p.add_argument("--out", required=True, help="Output path (.csv or .parquet).")
    return p.parse_args()


def coerce_int(s):
    try:
        return pd.to_numeric(s, errors="coerce").astype("Int64")
    except Exception:
        return pd.to_numeric(s, errors="coerce")


def main():
    args = parse_args()

    stats_path = Path(args.stats)
    contracts_path = Path(args.contracts)
    if not stats_path.exists():
        raise FileNotFoundError(f"Stats file not found: {stats_path}")
    if not contracts_path.exists():
        raise FileNotFoundError(f"Contracts file not found: {contracts_path}")

    stats = pd.read_excel(stats_path, sheet_name=args.sheet_stats)
    contracts = pd.read_excel(contracts_path, sheet_name=args.sheet_contracts)

    # Normalize join columns (case-insensitive; keep originals for output)
    def find_col(df, name):
        low = {c: str(c).strip().lower() for c in df.columns}
        for orig, l in low.items():
            if l == name.lower():
                return orig
        for orig, l in low.items():
            if name.lower() in l:
                return orig
        return None

    p_stats = find_col(stats, args.player_stats) or args.player_stats
    y_stats = find_col(stats, args.season_stats) or args.season_stats

    p_con = find_col(contracts, args.player_contracts) or args.player_contracts
    y_contr = find_col(contracts, args.contract_year_col) or args.contract_year_col
    years_col = find_col(contracts, args.years_col) or args.years_col
    total_col = find_col(contracts, args.total_value_col) or args.total_value_col

    for need, dfname in [(p_stats, "stats player"), (y_stats, "stats season"),
                         (p_con, "contracts player"), (y_contr, "contract year"),
                         (years_col, "contract years"), (total_col, "contract total value")]:
        if need not in (stats.columns.tolist() + contracts.columns.tolist()):
            raise ValueError(f"Required column for {dfname} not found. Check your arguments.")

    # Ensure season-like columns are numeric
    stats[y_stats] = coerce_int(stats[y_stats])
    contracts[y_contr] = coerce_int(contracts[y_contr])

    # Build feature table
    feat = stats.copy()
    # Keep only numeric features (plus id cols)
    id_cols = [p_stats, y_stats]
    num_cols = feat.select_dtypes(include=["number", "float", "int", "Int64"]).columns.tolist()
    num_cols = [c for c in num_cols if c not in id_cols]

    # Optionally compute rolling means over prior N seasons for each player
    if args.rolling and args.rolling > 0:
        feat = feat.sort_values([p_stats, y_stats])
        rolled = []
        grp = feat.groupby(p_stats, group_keys=False)
        # compute rolling mean on numeric columns
        r = grp.apply(lambda g: g.assign(**{
            f"{c}_r{args.rolling}": g[c].rolling(window=args.rolling, min_periods=1).mean()
            for c in num_cols
        }))
        # prefer rolled features only to avoid leakage from same-year aggregation across players
        feat = r
        # Keep only the rolled feature columns for modeling (optional: drop raw)
        rolled_cols = [f"{c}_r{args.rolling}" for c in num_cols]
        use_cols = id_cols + rolled_cols
        feat = feat[use_cols]
    else:
        # use raw numeric stats as features
        use_cols = id_cols + num_cols
        feat = feat[use_cols]

    # Contracts anchored at season = contract_year - offset
    contracts_anchor = contracts.copy()
    contracts_anchor["season"] = contracts_anchor[y_contr].astype("float") - float(args.align_offset)
    contracts_anchor["season"] = contracts_anchor["season"].round().astype("Int64")

    # Targets
    contracts_anchor["target_years"] = pd.to_numeric(contracts_anchor[years_col], errors="coerce")
    contracts_anchor["target_total_value"] = pd.to_numeric(contracts_anchor[total_col], errors="coerce")
    # Average Annual Value as auxiliary target
    with np.errstate(divide="ignore", invalid="ignore"):
        contracts_anchor["target_aav"] = contracts_anchor["target_total_value"] / contracts_anchor["target_years"]

    # Columns to pass through for traceability
    passthru = [p_con, y_contr, years_col, total_col]
    if args.id_pass_through:
        extra = [c.strip() for c in args.id_pass_through.split(",") if c.strip()]
        passthru.extend([c for c in extra if c in contracts_anchor.columns])

    # Prepare for merge: align player and season
    contracts_anchor = contracts_anchor.rename(columns={p_con: "player_key"})
    feat = feat.rename(columns={p_stats: "player_key", y_stats: "season"})

    merged = contracts_anchor.merge(feat, on=["player_key", "season"], how="left", validate="m:1")

    # Reorder columns: identifiers, targets, then features
    id_out = ["player_key", "season", y_contr] + [c for c in passthru if c not in [p_con, y_contr]]
    target_out = ["target_total_value", "target_years", "target_aav"]
    # feature columns are the rest
    feat_out = [c for c in merged.columns if c not in set(id_out + target_out)]
    merged = merged[id_out + target_out + feat_out]

    out_path = Path(args.out)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    if out_path.suffix.lower() == ".parquet":
        merged.to_parquet(out_path, index=False)
    else:
        merged.to_csv(out_path, index=False)

    print(f"Saved training table with {merged.shape[0]} rows and {merged.shape[1]} columns to: {out_path.resolve()}")
    print("Targets: target_total_value, target_years, target_aav")
    print(f"Sample columns: {merged.columns[:12].tolist()}")
    print("Note: rows with missing features will be imputed during training.")
    
if __name__ == "__main__":
    main()
