
"""
Train a multi-output regression model to predict contract size and length for hitters.

Usage:
    # Train Random Forest on total value + years:
    python src/train_contracts.py \
      --data data/hitters_contract_train.csv \
      --targets target_total_value,target_years \
      --model rf \
      --model-out artifacts/hitters_contracts_rf.pkl

    # Train Linear Regression on AAV only:
    python src/train_contracts.py \
      --data data/hitters_contract_train.csv \
      --targets target_aav \
      --model linear \
      --model-out artifacts/hitters_contract_aav_lin.pkl
"""

import argparse
from pathlib import Path
import pandas as pd
import numpy as np

from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor
from sklearn.multioutput import MultiOutputRegressor
from sklearn.metrics import r2_score, mean_absolute_error, mean_squared_error

import joblib

# Reuse the same preprocessor as the hitters pipeline
from pipeline_core import build_preprocessor

def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--data", required=True, help="CSV/Parquet built by build_contract_dataset.py")
    p.add_argument("--targets", required=True, help="Comma-separated target column(s), e.g. 'target_total_value,target_years'")
    p.add_argument("--test-size", type=float, default=0.2)
    p.add_argument("--random-state", type=int, default=42)
    p.add_argument("--model", choices=["linear", "rf"], default="linear",
                   help="Baseline model: 'linear' (multioutput LinearRegression) or 'rf' (MultiOutput RandomForest)")
    p.add_argument("--model-out", default="artifacts/hitters_contracts_model.pkl")
    return p.parse_args()


def evaluate_multi(y_true: pd.DataFrame, y_pred: np.ndarray, target_names):
    print("\n=== Regression Metrics (per target) ===")
    metrics = {}
    for idx, name in enumerate(target_names):
        yt = y_true.iloc[:, idx].to_numpy()
        yp = y_pred[:, idx] if y_pred.ndim == 2 else y_pred
        r2 = r2_score(yt, yp)
        mae = mean_absolute_error(yt, yp)
        rmse = mean_squared_error(yt, yp, squared=False)
        metrics[name] = {"R2": r2, "MAE": mae, "RMSE": rmse}
        print(f"{name:>20}  R^2={r2:7.4f}  MAE={mae:10.2f}  RMSE={rmse:10.2f}")
    # Print simple averages (ignoring NaNs)
    r2_avg = np.nanmean([m["R2"] for m in metrics.values()])
    mae_avg = np.nanmean([m["MAE"] for m in metrics.values()])
    rmse_avg = np.nanmean([m["RMSE"] for m in metrics.values()])
    print("\nAverages: "
          f"R^2={r2_avg:0.4f}  MAE={mae_avg:0.2f}  RMSE={rmse_avg:0.2f}")
    return metrics


def main():
    args = parse_args()
    data_path = Path(args.data)
    if not data_path.exists():
        raise FileNotFoundError(f"Data not found: {data_path}")

    # Load data
    if data_path.suffix.lower() == ".parquet":
        df = pd.read_parquet(data_path)
    else:
        df = pd.read_csv(data_path)

    target_cols = [c.strip() for c in args.targets.split(",") if c.strip()]
    for t in target_cols:
        if t not in df.columns:
            raise ValueError(f"Target column '{t}' not in data. Available: {list(df.columns)[:20]}...")

    # X = all features (drop id/target columns)
    id_like = [c for c in ["player_key", "season"] if c in df.columns]
    X = df.drop(columns=id_like + target_cols, errors="ignore")
    y = df[target_cols].copy()

    # Train/test split
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=args.test_size, random_state=args.random_state
    )

    # Preprocess
    cat_cols = X_train.select_dtypes(include=["object", "category", "bool"]).columns.tolist()
    num_cols = X_train.select_dtypes(include=["number", "float", "int", "Int64"]).columns.tolist()
    pre = build_preprocessor(num_cols, cat_cols)

    # Model
    if args.model == "linear":
        # LinearRegression supports multi-output natively
        model = LinearRegression()
    else:
        base = RandomForestRegressor(
            n_estimators=400, random_state=args.random_state, n_jobs=-1
        )
        model = MultiOutputRegressor(base, n_jobs=None)

    pipe = Pipeline([("preprocess", pre), ("model", model)])
    pipe.fit(X_train, y_train)

    # Predict & evaluate
    y_pred = pipe.predict(X_test)
    evaluate_multi(y_test, y_pred, target_cols)

    # Persist model
    out = Path(args.model_out)
    out.parent.mkdir(parents=True, exist_ok=True)
    joblib.dump(pipe, out)
    print(f"\nSaved trained contract model to: {out.resolve()}")

if __name__ == "__main__":
    main()
